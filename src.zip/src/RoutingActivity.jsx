import Sidebar from './Sidebar';
import MainContent from './MainContent';
import { BrowserRouter } from "react-router-dom";

export default function RoutingActivity(){

	return<>
	<BrowserRouter>
      <div style={{ display: "flex" }}>
        <Sidebar />
        <MainContent />
      </div>
    </BrowserRouter>

	</>

}