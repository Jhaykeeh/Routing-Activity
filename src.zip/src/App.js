import { useState } from 'react';
function App() {
  const [student, setStudent] = useState({
    fullname: '',
    studentId: '',
    department: '',
    courseYr: '',
    picture: ''
  });

  //  ARRAY of students
  const [students, setStudents] = useState([]);

  //  index for prev/next
  const [index, setIndex] = useState(0);

  const handleChange = (e) => {
    setStudent({
      ...student,
      [e.target.name]: e.target.value
    });
  };

  //  ADD student to array
  const handleSubmit = () => {
    setStudents([...students, student]);

    // reset form
    setStudent({
      fullname: '',
      studentId: '',
      department: '',
      courseYr: '',
      picture: ''
    });

    setIndex(students.length); // move to new student
  };

  const nextStudent = () => {
    if (index < students.length - 1) {
      setIndex(index + 1);
    }
  };

  const prevStudent = () => {
    if (index > 0) {
      setIndex(index - 1);
    }
  };

  const current = students[index];

  return (
    <div
      className="App"
      style={{
        display: 'flex',
        justifyContent: 'space-around',
        padding: '20px'
      }}
    >
      
      <div style={{ width: '40%' }}>
        <h2>Student Data</h2>

        <label>Student ID</label>
        <input name="studentId" value={student.studentId} onChange={handleChange} />

        <label>Full Name</label>
        <input name="fullname" value={student.fullname} onChange={handleChange} />


        <label>Department</label>
        <input name="department" value={student.department} onChange={handleChange} />


        <label>Course Year</label>
        <input name="courseYr" value={student.courseYr} onChange={handleChange} />


        <label>Picture Link</label>
        <input name="picture" value={student.picture} onChange={handleChange} />


        <button onClick={handleSubmit}  style={{ width: '150px', height: '50px', fontSize: '16px'}}>Add Student</button>
      </div>


      <div style={{ width: '40%', textAlign: 'center' }}>
        <h2>Student Viewer</h2>

        {students.length > 0 ? (
          <>
            {current.picture && (
              <img
                src={current.picture}
                alt="student"
                width="200"
                height="200"
                style={{ objectFit: 'cover', borderRadius: '10px' }}
              />
            )}

            <h3>{current.fullname}</h3>
            <p>ID: {current.studentId}</p>
            <p>Department: {current.department}</p>
            <p>Year: {current.courseYr}</p>

            {/* NAV BUTTONS */}
            <div style={{ marginTop: '20px' }}>
              <button onClick={prevStudent}  disabled={index === 0}>
                 Prev
              </button>

              <span style={{ margin: '0 10px' }}>
                {index + 1} / {students.length}
              </span>

              <button onClick={nextStudent} disabled={index === students.length - 1}>
                Next 
              </button>
            </div>
          </>
        ) : (
          <p>No students added yet</p>
        )}
      </div>
    </div>
  );
}

export default App;
