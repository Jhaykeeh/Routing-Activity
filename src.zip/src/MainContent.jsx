import { Routes, Route } from "react-router-dom";
import App from "./App";
import CashierQueueSimulator from "./cashier/CashierQueueSimulator";
import TodoPage from "./ToDo/TodoPage";

export default function MainContent() {
  return (
    <div
      style={{
        backgroundColor: "lightgray",
        width: "80%",
        height: "100vh",
      }}
    >
      <Routes>
        
        <Route path="/" element={<App />} />

        
        <Route
          path="/cashier"
          element={<CashierQueueSimulator />}
        />

        <Route
          path="/todo"
          element={< TodoPage/>}
        />

        {/* Logout */}
        <Route
          path="/logout"
          element={<h2>Logout Page</h2>}
        />
      </Routes>
    </div>
  );
}