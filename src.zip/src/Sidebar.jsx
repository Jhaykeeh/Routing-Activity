import { Link } from 'react-router-dom';

export default function Sidebar() {
  return (
    <div style={{ backgroundColor: "gray", width: "20%" }}>
      <h3>Sidebar</h3>

      <p>
        <Link to="/">Student Activity</Link>
      </p>

      <p>
        <Link to="/cashier">Cashier Queue Simulator</Link>
      </p>

      <p>
        <Link to="/todo">To do List</Link>
      </p>

      <p>
        <Link to="/profile">Student Card</Link>
      </p>

      <p>
        <Link to="/logout">Logout</Link>
      </p>
    </div>
  );
}