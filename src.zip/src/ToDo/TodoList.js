import { useContext } from "react";
import { TodoContext } from "./TodoContext";

export default function TodoList() {

    const { state, dispatch } = useContext(TodoContext);

    return (

        <ul>

            {state.map((todo) => (

                <li key={todo.id}>

    <span
        onClick={() =>
            dispatch({
                type: "TOGGLE_TODO",
                payload: todo.id
            })
        }
        style={{
            textDecoration: todo.done ? "line-through" : "none",
            cursor: "pointer"
        }}
    >
        {todo.text}
    </span>

    <button
        onClick={() =>
            dispatch({
                type: "DELETE_TODO",
                payload: todo.id
            })
        }
    >
        ❌
    </button>

</li>

            ))}

        </ul>

    );

}