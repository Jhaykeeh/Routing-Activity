import { TodoProvider } from "./TodoContext";
import TodoInput from "./TodoInput";
import TodoList from "./TodoList";

export default function TodoPage() {
  return (
    <TodoProvider>
      <TodoInput />
      <TodoList />
    </TodoProvider>
  );
}